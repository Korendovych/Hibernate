/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ormnba;

/**
 *
 * @author koren
 */
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.TransientPropertyValueException;
import org.hibernate.exception.ConstraintViolationException;

public class InsertarEstadisticas {

    public static void main(String args[]) {

        SessionFactory sesion = HibernateUtil.getSesionFactory();
        Session session = sesion.openSession();
        Transaction tx = session.beginTransaction();

        Estadisticas est = new Estadisticas();
        EstadisticasId estid = new EstadisticasId();
        

         estid.setJugador(123); 
         estid.setTemporada("05/06");
        
         est.setId(estid);
         est.setId(estid);
         est.setPuntosPorPartido((float)7);
         est.setRebotesPorPartido((float)5);
         est.setAsistenciasPorPartido((float)0);
         est.setTaponesPorPartido((float)0);

      /*   
         estid.setJugador(123); 
         estid.setTemporada("06/07");
         
         est.setId(estid);
         est.setId(estid);
         est.setPuntosPorPartido((float)10);
         est.setRebotesPorPartido((float)5);
         est.setAsistenciasPorPartido((float)0);
         est.setTaponesPorPartido((float)3);*/
        try {
            
            session.save(est);
            System.out.println("DATOS INSERTADIS CORRECTAMENTE");
            try {
                tx.commit();
            } catch (ConstraintViolationException e) {
                System.out.println("Estadistica duplicada");
                System.out.println("MENSAJE: " + e.getMessage());
                System.out.println("COD ERROR: " + e.getErrorCode());
                System.out.println("ERROR SQL: " + e.getSQLException().getMessage());
            }
        } catch (TransientPropertyValueException ee) {
            System.out.println("EL JUGADOE NE EXISTE");
            System.out.println("Mensaje: " + ee.getMessage());

        }
        session.close();
        System.exit(0);

    }

}
