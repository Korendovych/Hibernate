/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ormnba;

/**
 *
 * @author koren
 */
import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;
import org.hibernate.Query;

import org.hibernate.Session;
import org.hibernate.SessionFactory;

public class CadaEquipo {

    public static void main(String args[]) {

        //select e.jugadores.equipos.nombre from Estadisticas as e group by e.jugadores.equipos.nombre
        SessionFactory sesion = HibernateUtil.getSesionFactory();
        Session session = sesion.openSession();

        
        Query q2 = session.createQuery("select coalesce(avg(puntosPorPartido)), e.jugadores.codigo, e.jugadores.nombre, e.jugadores.equipos.nombre from Estadisticas as e group by e.jugadores");
       // q2.setFetchSize(10);
        // Iterator iter2 = q2.iterate();
        Query q1 = session.createQuery("select coalesce(avg(puntosPorPartido)), e.jugadores.equipos.nombre from Estadisticas as e group by e.jugadores.equipos.nombre");
        List<Object[]> filas = q2.list();
        List<Object[]> filas1 = q1.list();
        
        System.out.println("Numero de equipos: "+filas1.size());
        
        for (int j = 0; j < filas1.size(); j++) {

            Object[] filaActual3 = filas1.get(j);
            System.out.println("======================");
            System.out.println("Equipo: " +filaActual3[1]);

           for (int i =0; i < filas.size(); i++) {
                Object[] filaActual1 = filas1.get(j);
                Object[] filaActual2 = filas.get(i);
                
               if (filaActual1[1].equals(filaActual2[3])) {

                    System.out.println(filaActual2[1] + ", " + filaActual2[2] + ":\t" + filaActual2[0]);
                }

            }
            System.out.println("......................");
        }
        
        session.close();
        System.exit(0);
    }

  
}
