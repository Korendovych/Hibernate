/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ormnba;

import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Iterator;
import java.util.Scanner;
import org.hibernate.Query;

import org.hibernate.Session;
import org.hibernate.SessionFactory;

/**
 *
 * @author koren
 */
public class Estadistica {
    
    public static void main (String args[]){
        Scanner scan = new Scanner (System.in);
        
    
        SessionFactory sesion = HibernateUtil.getSesionFactory();
        Session session = sesion.openSession();

        Query q1 = session.createQuery("from Jugadores");

        q1.setFetchSize(10);
        Iterator iter1 = q1.iterate();
        
        System.out.println("Introduzca el codigo del jugador: ");
        int cod=0;
        try{
        cod = scan.nextInt();
        
        //ArrayList<Integer> listaJug = new ArrayList<Integer>();

        while (iter1.hasNext()) {
            
            Jugadores jug = (Jugadores) iter1.next();
            if(cod==jug.getCodigo()){
                System.out.println("DATOS DEL JUGADOR: "+cod);
                System.out.println("Nombre: "+jug.getNombre());
                System.out.println("Equipo: "+jug.getEquipos().getNombre());
            }
            //listaJug.add(jug.getCodigo());
        }

        int countReg=0;
        Query q2 = session.createQuery("from Estadisticas");
        q2.setFetchSize(10);
        Iterator iter2 = q2.iterate();
        System.out.println("Temporada      Ptos      Asis      Tap      Reb\t");
        System.out.println("================================================");
        while (iter2.hasNext()) {

            Estadisticas est = (Estadisticas) iter2.next();

            if(cod==est.getJugadores().getCodigo()){
                
                System.out.println(est.getId().getTemporada()+"          "+est.getPuntosPorPartido()+"      "+
                        est.getAsistenciasPorPartido()+"       "+est.getTaponesPorPartido()+"      "+
                        est.getRebotesPorPartido()+"\t");
                
                countReg++;
               
            }
        }
        System.out.println("================================================");
        System.out.println("Numero de registros: "+countReg);
        System.out.println("================================================");

        }catch(InputMismatchException ime){
            System.out.println("El parámetro no es correcto (debe ser numérico) ");
        }
        session.close();
        System.exit(0);
    }
}
